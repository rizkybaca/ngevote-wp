<?php
date_default_timezone_set("Asia/Bangkok");

$koneksi = new mysqli ("localhost","root","","votelokal");
?>