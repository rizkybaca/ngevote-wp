<div class="card card-primary">
	<div class="card-header">
		<h3 class="card-title">
			<i class="fa fa-edit"></i> Tambah Data</h3>
	</div>
	<form action="" method="post" enctype="multipart/form-data">
		<div class="card-body">

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">No. urut</label>
				<div class="col-sm-6">
					<input type="number" class="form-control" id="id_calon" name="ini_id" placeholder="silakan isi nomor urut kandidat di sini" required>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Nama Kandidat</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" id="nama_calon" name="ini_nama" placeholder="silakan isi nama lengkap kandidat di sini">
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Foto Kandidat</label>
				<div class="col-sm-6">
					<input type="file" id="foto_calon" name="ini_foto">
					<p class="help-block">
						<font color="red">"Format file .jpg"</font>
					</p>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label" for="visi">Visi</label>
				<div class="col-sm-6">
					<textarea class="form-control" id="visi" name="ini_visi" placeholder="silakan isi visi kandidat di sini"></textarea>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label" for="misi">Misi</label>
				<div class="col-sm-6">
					<textarea class="form-control" id="misi" name="ini_misi" placeholder="silakan isi misi kandidat di sini"></textarea>
				</div>
			</div>

		</div>
		<div class="card-footer">
			<input type="submit" name="Simpan" value="Simpan" class="btn btn-info">
			<a href="?page=data-calon" title="Kembali" class="btn btn-secondary">Batal</a>
		</div>
	</form>
</div>

<?php

    function upload(){

    // $sumber = @$_FILES['foto_calon']['tmp_name'];
    // $target = 'foto/';
    // $nama_file = @$_FILES['foto_calon']['name'];
    // $pindah = move_uploaded_file($sumber, $target.$nama_file);

	    $namaFile=$_FILES['ini_foto']['name'];
	    $ukuranFile=$_FILES['ini_foto']['size'];
	    $error=$_FILES['ini_foto']['error'];
	    $tmpName=$_FILES['ini_foto']['tmp_name'];
	    $target='foto/';

	    if ($error===4) {
	    	echo "<script>
				Swal.fire({title: 'Gagal, foto wajib diisi',text: '',icon: 'error',confirmButtonText: 'OK'
				}).then((result) => {
					if (result.value) {
						window.location = 'index.php?page=add-calon';
					}
				})</script>";
	    }

	    $ekstensiValid=['jpg', 'jpeg'];
	    $ekstensiFoto=explode('.', $namaFile);
	    $ekstensiFoto=strtolower(end($ekstensiFoto));

	    if (in_array($ekstensiFoto, $ekstensiValid)) {
	    	echo "<script>
				Swal.fire({title: 'Gagal, silakan unggah foto sesuai ekstensi',text: '',icon: 'error',confirmButtonText: 'OK'
				}).then((result) => {
					if (result.value) {
						window.location = 'index.php?page=add-calon';
					}
				})</script>";
	    }
	        
	   	if ($ukuranFile>2000000) {
	   		echo "<script>
				Swal.fire({title: 'Gagal, ukuran foto terlalu besar!',text: '',icon: 'error',confirmButtonText: 'OK'
				}).then((result) => {
					if (result.value) {
						window.location = 'index.php?page=add-calon';
					}
				})</script>";
		}		

	   	$namaFileBaru=uniqid();   	
	   	$namaFileBaru.='.';
	   	$namaFileBaru.=$ekstensiFoto;
	   	move_uploaded_file($tmpName, $target.$namaFileBaru);

	   	return $namaFileBaru;
	}

    

    if (isset ($_POST['Simpan'])){
    	$id=htmlspecialchars($_POST["ini_id"]);
    	$nama=htmlspecialchars($_POST["ini_nama"]);
    	$visi=htmlspecialchars($_POST["ini_visi"]);
    	$misi=htmlspecialchars($_POST["ini_misi"]);
    	$foto=upload();

		$sql_simpan = "INSERT INTO tb_calon (id_calon, nama_calon, foto_calon, visi, misi) VALUES (
		    '$id', '$nama', '$foto', '$visi', '$misi')
		";
		$query_simpan = mysqli_query($koneksi, $sql_simpan);
		mysqli_close($koneksi);

		    if ($query_simpan) {
		      echo "<script>
		      Swal.fire({title: 'Tambah Data Berhasil',text: '',icon: 'success',confirmButtonText: 'OK'
		      }).then((result) => {if (result.value){
		          window.location = 'index.php?page=data-calon';
		          }
		      })</script>";
		    }else{
		      echo "<script>
		      Swal.fire({title: 'Tambah Data Gagal',text: '',icon: 'error',confirmButtonText: 'OK'
		      }).then((result) => {if (result.value){
		          window.location = 'index.php?page=add-calon';
		          }
		      })</script>";
			}
	}
   
